<?php
session_start();

if (!isset($_SESSION['user_name']) && !isset($_SESSION['admin_name'])) {
    header('location: signin.php');
    exit;
}

include_once 'config.php';

$user_name = isset($_SESSION['user_name']) ? $_SESSION['user_name'] : $_SESSION['admin_name'];
$user_type = isset($_SESSION['user_name']) ? 'user' : 'admin';

if ($user_type === 'user') {
    $select_query = "SELECT name, email FROM user_form WHERE email = '{$_SESSION['user_name']}'";
} else {
    $select_query = "SELECT name, email FROM admin_users WHERE email = '{$_SESSION['admin_name']}'";
}

$result = mysqli_query($conn, $select_query);

if ($result && mysqli_num_rows($result) > 0) {
    $row = mysqli_fetch_assoc($result);
    $name = $row['name'];
    $email = $row['email'];
} else {
    $name = '';
    $email = '';
}

mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Dashboard</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bulma/0.9.3/css/bulma.min.css">
    <style>
        body {
            background-color: grey;
            height: 100vh;
        }

        .profile-container {
            display: flex;
            flex-direction: column;
            align-items: center;
            padding: 20px;
            text-align: center;
        }

        .profile-image {
            margin-bottom: 20px;
        }

        .dark-bordered {
            border-color: #363636;
        }

        @media screen and (min-width: 768px) {
            .profile-container {
                padding-top: 50px;
            }
        }
    </style>
</head>

<body>
    <nav class="navbar is-info has-navbar-fixed-top" role="navigation" aria-label="main navigation">
        <div class="navbar-brand">
            <a role="button" class="navbar-burger burger" aria-label="menu" aria-expanded="false" data-target="navbarBasicExample">
                <span aria-hidden="true"></span>
                <span aria-hidden="true"></span>
                <span aria-hidden="true"></span>
            </a>
        </div>

        <div id="navbarBasicExample" class="navbar-menu">
            <div class="navbar-end">
                <div class="navbar-item">
                    <div class="buttons">
                        <a class="navbar-item has-text-dark has-text-weight-bold" href="dashboard.php">
                            Home
                        </a>
                        <a class="navbar-item has-text-dark has-text-weight-bold" href="quiz.php">
                            Quiz
                        </a>
                        <a class="navbar-item has-text-dark has-text-weight-bold" href="responses.php">
                            Your Responses
                        </a>
                        <a href="logout.php" class="button is-danger">
                            Logout
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </nav>

    <section class="section">
        <div class="container">
            <div class="columns is-centered">
                <div class="column is-half">
                    <div class="box is-bordered dark-bordered">
                        <div class="profile-container">
                            <div class="profile-image">
                                <img src="images/user.png" alt="Default Profile Picture" width="150" height="150">
                            </div>
                            <h1 class="title">Welcome, <?php echo htmlspecialchars($user_name); ?>!</h1>
                            <h2 class="subtitle">You are logged in as a <?php echo htmlspecialchars($user_type); ?>.</h2>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <script>
        document.addEventListener('DOMContentLoaded', () => {
            const $navbarBurgers = Array.prototype.slice.call(document.querySelectorAll('.navbar-burger'), 0);
            if ($navbarBurgers.length > 0) {
                $navbarBurgers.forEach(el => {
                    el.addEventListener('click', () => {
                        const target = el.dataset.target;
                        const $target = document.getElementById(target);
                        el.classList.toggle('is-active');
                        $target.classList.toggle('is-active');
                    });
                });
            }
        });
    </script>
</body>

</html>


