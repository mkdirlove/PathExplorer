<?php
session_start();
include_once 'config.php';

if (!isset($_SESSION['user_name'])) {
    header('location: signin.php');
    exit;
}

$user_name = $_SESSION['user_name']; 
$responses = [];

foreach ($_POST as $question_id => $answer) {
    $question_id = str_replace('q', '', $question_id);
    $responses[] = "('$user_name', $question_id, '" . mysqli_real_escape_string($conn, $answer) . "')";
}

if (!empty($responses)) {
    $query = "INSERT INTO responses (user_name, question_id, answer) VALUES " . implode(',', $responses);
    if (mysqli_query($conn, $query)) {
        header('Location: quiz_confirmation.php');
        exit;
    } else {
        echo "Error: " . mysqli_error($conn);
    }
} else {
    echo "No responses to submit.";
}

mysqli_close($conn);
?>
