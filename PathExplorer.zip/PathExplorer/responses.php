<?php
session_start();
include_once 'config.php';

if (!isset($_SESSION['user_name'])) {
    header('location: signin.php');
    exit;
}

$user_name = $_SESSION['user_name'];

if (isset($_POST['retake_quiz'])) {
    $delete_query = "DELETE FROM responses WHERE user_name = '$user_name'";
    mysqli_query($conn, $delete_query);
    header('Location: quiz.php');
    exit;
}

$query = "SELECT q.question_text, r.answer 
          FROM responses r 
          INNER JOIN questions q ON r.question_id = q.id 
          WHERE r.user_name = '$user_name'";
$result = mysqli_query($conn, $query);

$responses = [];
if ($result && mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_assoc($result)) {
        $responses[] = $row;
    }

    $custom1 = "
    1. The Arts and Design Track: Prepares students for careers in music, visual arts, performing arts, and industrial arts. It develops creative and entrepreneurial skills for modern careers.
    2. ABM Track (Accountancy, Business, and Management Strand): Lays the foundation for business-related college degrees, covering financial management, accounting, and corporate operations. It prepares future business leaders and entrepreneurs.
    3. STEM (Science, Technology, Engineering, and Mathematics): Prepares students for college degrees in STEM fields, enhancing their scientific, technological, engineering, and mathematical skills.
    4. GAS (General Academic Strand): Offers a broad range of academic disciplines, including social sciences, humanities, management, and organization, allowing students to explore various college degree options.
    5. EIM (Electrical Installation and Maintenance): Focuses on skills for installing, repairing, and maintaining electrical systems, suitable for those interested in working with electrical setups.
    6. HUMSS (The Humanities and Social Sciences Strand): Covers liberal arts topics, enhancing skills in thinking, writing, and speaking about humanistic and societal issues. It prepares students for higher education in arts, political science, literature, and related fields.
    7. ICT (Information and Communication Technology): Prepares students for careers in technology, equipping them with skills in computer systems, programming, web development, and basic animation.
    8. HE (Home Economics Strand ): Teaches practical skills for starting small businesses or finding jobs, focusing on skills that can be used at home.
    9. The Machining Strand: Provides training in machining and metalworking techniques, preparing students for careers in manufacturing, automotive, aerospace, and engineering as machinists and CNC operators.
    10 TG (Tour Guiding): Trains individuals to become effective tour guides, covering local history, culture, geography, hospitality, and communication skills. It includes practical experience in tourist destinations.
    ";

    $responses_text = "";
    foreach ($responses as $response) {
        $responses_text .= $response['question_text'] . " " . $response['answer'] . " ";
    }

    $query = "based on the " . $responses_text . " suggest track or strand from " . $custom1 . "without any other recommendations";

    $api_url = "https://api.easy-api.online/v1/globalgpt?q=" . urlencode($query);

    $response = file_get_contents($api_url);

    if ($response !== false) {
        $data = json_decode($response, true);

        if ($data !== null) {
            $plain_text = strip_tags(json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT));
            
            $plain_text = preg_replace('/[^A-Za-z0-9\s]/', '', $plain_text);
            
            $plain_text = str_replace("content", "", $plain_text);

            $suggested_tracks = $plain_text;
        } else {
            $suggested_tracks = "Error decoding JSON response.";
        }
    } else {
        $suggested_tracks = "Error calling the API.";
    }
} else {
    $responses = [];
}

mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>List of Tracks</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bulma/0.9.3/css/bulma.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
        }

        h1 {
            text-align: center;
        }

        .response {
            margin-top: 20px;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .suggestions {
            margin-top: 20px;
        }

        .suggestions p {
            font-weight: bold;
        }
    </style>
</head>

<body>
    <!-- Navigation bar -->
    <nav class="navbar is-info has-navbar-fixed-top" role="navigation" aria-label="main navigation">
        <div class="navbar-brand">
            <a role="button" class="navbar-burger burger" aria-label="menu" aria-expanded="false" data-target="navbarBasicExample">
                <span aria-hidden="true"></span>
                <span aria-hidden="true"></span>
                <span aria-hidden="true"></span>
            </a>
        </div>

        <div id="navbarBasicExample" class="navbar-menu">
            <div class="navbar-end">
                <div class="navbar-item">
                    <div class="buttons">
                        <a class="navbar-item has-text-dark has-text-weight-bold" href="dashboard.php">Home</a>
                        <a class="navbar-item has-text-dark has-text-weight-bold" href="quiz.php">Quiz</a>
                        <a class="navbar-item has-text-dark has-text-weight-bold" href="responses.php">
                            Your Responses
                        </a>
                        <a href="logout.php" class="button is-danger">Logout</a>
                    </div>
                </div>
            </div>
        </div>
    </nav>

    <section class="section">
        <div class="container">
            <form method="post">
                <br>
                <button type="submit" name="retake_quiz" class="button is-warning is-pulled-right">Retake Quiz</button>
            </form>
            <h1 class="title">Track / Strand Suggestions</h1>
            <div class="response">
                <?php if (!empty($responses)): ?>
                    <div class="suggestions">
                        <div class="notification is-info">
                            <?php echo nl2br($suggested_tracks); ?>
                        </div>
                    </div>
                <?php else: ?>
                    <div class="notification is-warning">
                        No responses found. Can't suggest Track / Strand.
                    </div>
                <?php endif; ?>
                <br>
                <h1 class="title">Your Responses</h1>
                <table class="table is-bordered is-striped is-narrow is-hoverable is-fullwidth">
                    <thead>
                        <tr>
                            <th>Question</th>
                            <th>Answer</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($responses)): ?>
                            <?php foreach ($responses as $response): ?>
                                <tr>
                                    <td><?php echo $response['question_text']; ?></td>
                                    <td><?php echo $response['answer']; ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="2">No responses found.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </section>
</body>

</html>
