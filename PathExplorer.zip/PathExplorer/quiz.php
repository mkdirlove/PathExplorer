<?php
session_start();
include_once 'config.php';

// Check if user has already taken the quiz
$user_name = $_SESSION['user_name'];
$query = "SELECT * FROM responses WHERE user_name = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("s", $user_name);
$stmt->execute();
$result = $stmt->get_result();
$user_has_taken_quiz = $result->num_rows > 0;

if (!$user_has_taken_quiz) {
    // Fetch questions from the database
    $query = "SELECT * FROM questions";
    $result = mysqli_query($conn, $query);
    $questions = [];

    if ($result) {
        while ($row = mysqli_fetch_assoc($result)) {
            $questions[] = $row;
        }
    }

    mysqli_close($conn);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quiz</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bulma/0.9.3/css/bulma.min.css">
</head>
<body>
<nav class="navbar is-info has-navbar-fixed-top" role="navigation" aria-label="main navigation">
    <div class="navbar-brand">
        <a role="button" class="navbar-burger burger" aria-label="menu" aria-expanded="false" data-target="navbarBasicExample">
            <span aria-hidden="true"></span>
            <span aria-hidden="true"></span>
            <span aria-hidden="true"></span>
        </a>
    </div>

    <div id="navbarBasicExample" class="navbar-menu">
        <div class="navbar-end">
            <div class="navbar-item">
                <div class="buttons">
                    <a class="navbar-item has-text-dark has-text-weight-bold" href="dashboard.php">Home</a>
                    <a class="navbar-item has-text-dark has-text-weight-bold" href="quiz.php">Quiz</a>
                    
                    <a class="navbar-item has-text-dark has-text-weight-bold" href="responses.php">
                            Your Responses
                        </a>
                    <a href="logout.php" class="button is-danger">Logout</a>
                </div>
            </div>
        </div>
    </div>
</nav>

<section class="section">
    <div class="container">
        <?php if ($user_has_taken_quiz): ?>
            <div class="notification is-warning">
                <strong>You have already taken the quiz.</strong>
            </div>
        <?php else: ?>
            <form action="quiz_submit.php" method="POST">
                <?php
                $current_category = '';
                foreach ($questions as $question) {
                    if ($current_category !== $question['category']) {
                        if ($current_category !== '') {
                            echo '<hr>';
                        }
                        $current_category = $question['category'];
                        echo "<h1 class='title'>{$current_category}</h1>";
                    }
                    echo "<div class='field'>
                            <label class='label'>{$question['question_text']}</label>";
                    if ($question['question_type'] === 'text') {
                        echo "<div class='control'>
                                <input class='input' type='text' name='q{$question['id']}' required>
                              </div>";
                    } else {
                        echo "<div class='control'>
                                <label class='radio'>
                                    <input type='radio' name='q{$question['id']}' value='Yes'> Yes
                                </label>
                                <label class='radio'>
                                    <input type='radio' name='q{$question['id']}' value='No'> No
                                </label>
                              </div>";
                    }
                    echo "</div>";
                }
                ?>
                <div class="field is-grouped">
                    <div class="control">
                        <button class="button is-primary" type="submit">Submit</button>
                    </div>
                    <div class="control">
                        <button class="button is-link" type="reset">Reset</button>
                    </div>
                </div>
            </form>
        <?php endif; ?>
    </div>
</section>
<script>
    document.addEventListener('DOMContentLoaded', () => {
        const $navbarBurgers = Array.prototype.slice.call(document.querySelectorAll('.navbar-burger'), 0);
        if ($navbarBurgers.length > 0) {
            $navbarBurgers.forEach(el => {
                el.addEventListener('click', () => {
                    const target = el.dataset.target;
                    const $target = document.getElementById(target);
                    el.classList.toggle('is-active');
                    $target.classList.toggle('is-active');
                });
            });
        }
    });
</script>

</body>
</html>
