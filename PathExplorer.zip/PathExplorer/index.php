<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Career Path Explorer</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bulma/0.9.3/css/bulma.min.css">
  <style>
    .hero {
      background: url('images/header.png') no-repeat center center;
      background-size: cover;
      color: white;
    }

    .hero .hero-body {
      background: rgba(0, 0, 0, 0.5);
    }

    .hero a.cta {
      background-color: #00d1b2;
      color: white;
    }

    p {
      text-align: justify;
    }
  </style>
</head>

<body>
  <!-- Navigation bar -->
  <nav class="navbar is-fixed-top is-info" role="navigation" aria-label="main navigation">
    <div class="navbar-brand">
      <a class="navbar-item" href="#">
        <img src="images/pic.png" alt="Company Logo">
      </a>
      <a role="button" class="navbar-burger" aria-label="menu" aria-expanded="false" data-target="navbarBasicExample">
        <span aria-hidden="true"></span>
        <span aria-hidden="true"></span>
        <span aria-hidden="true"></span>
      </a>
    </div>

    <div id="navbarBasicExample" class="navbar-menu">
      <div class="navbar-end">
        <a class="navbar-item" href="#top">Home</a>
        <a class="navbar-item" href="#about">Tracks / Strands</a>
        <a class="navbar-item" href="signin.php">Sign Up / Sign In</a>
      </div>
    </div>
  </nav>

  <!-- Hero section -->
  <section class="hero is-medium">
    <div class="hero-body">
      <div class="container has-text-centered">
        <br>
        <h1 class="title has-text-white">CAREER PATH EXPLORER</h1>
        <p class="subtitle has-text-white has-text-centered">We're here to help for your future.</p>
        <a href="signin.php" class="button is-primary is-large cta">Get Started</a>
      </div>
    </div>
  </section>

 <!-- Main content -->
 <section class="section" id="about">
    <div class="container">
      <h2 class="title">Tracks / Strands</h2>
      <div class="content">
        <h3 class="subtitle">1. The Arts and Design Track</h3>
        <p>Prepares students for higher education in performance and creative fields. This route seeks to help individuals realize their full potential and develop the inventive thinking required for modern applications. It offers specializations that prepare students for careers in music, media and visual arts, performing arts, and industrial arts. Students who study arts and design not only hone their creative skills, but also turn them into a viable career. Learning arts and design does not end with concept and creation. Students are taught entrepreneurship skills so that they can compete in the job market.</p>
          <ul>
          <h3 class="subtitle">Courses</h3>
            <li>BS in Interior Design			</li>
            <li>BS in Industrial Design</li>
            <li>AB in Digital Film</li>
            <li>AB in Digital Journalism</li>
            <li>AB in Advertising Design</li>
            <li>Master in Multimedia Arts</li>
            <li>Associate in Multimedia Technologies</li>
            <li>Professional Assistant Animator NCIII</li>
            <li>Visual Grapics Design</li>
            <li>Computer-Aided Design and Drafting</li>
            <li>Animation NCII</li>
            <li>Associate in Computer Graphics and Animation</li>
            <li>BA in Philippine Arts</li>
            <li>Bachelor of Fine Arts</li>
            <li>Diploma in Photojournalism</li>
          </ul>
          <ul>
          <h3 class="subtitle">Job Opportunities</h3>
            <li>Graphic Designer</li>
            <li>Animator</li>
            <li>Fashion Designer</li>
            <li>Interior Designer</li>
            <li>Art Director</li>
            <li>UI/UX Designer</li>
          </ul>
        <h3 class="subtitle">2. ABM Track (Accountancy, Business, and Management Strand)</h3>
        <p>The ABM strand aims to ready future business leaders by laying the foundation for business-oriented college degrees. It covers fundamental aspects of financial management, accounting, and corporate operations, with the objective of fostering essential skills required for success in future careers and entrepreneurial ventures. Understanding business and finance can be tough, but diving into ABM strand programs can help budding entrepreneurs, like you, develop the mindset needed for successful careers. Keep reading to learn more about this strand.</p>
        <ul>
          <h3 class="subtitle">Courses</h3>
            <li>BS Accountancy</li>
            <li>BS Accounting Technology</li>
            <li>BS Accounting Information System</li>
            <li>BS Entrepreneurship</li>
            <li>BS Business Administration</li>
            <li>BS Finance</li>
            <li>BS Economics</li>
            <li>BS Customs Administration</li>
            <li>BS Legal Management</li>
            <li>BS Human Resources Management</li>
            <li>BS Community Development</li>
            <li>BS Business Management</li>
          </ul>
          <ul>
          <h3 class="subtitle">Job Opportunities</h3>
            <li>Accountant </li>
            <li>Auditor</li>
            <li>IT Project Manager</li>
            <li>Business/Finance Analyst</li>
            <li>Enterpreneur</li>
          </ul>
        <h3 class="subtitle">3. STEM: Science, Technology, Engineering, and Mathematics</h3>
        <p>Designed to prepare upcoming senior high school students who are interested in taking college degrees focused on STEM, senior high school students will be exposed to learning activities that will improve their knowledge and skills to integrate scientific, technological, engineering, and mathematical ideas.</p>
        <h3 class="subtitle">Courses</h3>
            <li>BS Nursing</li>
            <li>BS Medical Technology</li>
            <li>BS Pharmacy</li>
            <li>BS Food Technology</li>
            <li>BS Environmental Science</li>
            <li>BS Chemistry</li>
            <li>BS Materials Engineering</li>
            <li>BS Electronics and Communications Engineering</li>
            <li>BS Chemical Engineering</li>
            <li>BS Mechanical Engineering</li>
            <li>BS Geodetic Engineering</li>
            <li>BS Applied Mathematics</li>
            <li>BS Mathematics</li>
            <li>BS Statistics</li>
            <li>BS Secondary Education (major in Mathematics)</li>
          </ul>
          <ul>
          <h3 class="subtitle">Job Opportunities</h3>
            <li>Computer Systems Analyst</li>
            <li>Database Administrator</li>
            <li>IT Director</li>
            <li>Network Administrator</li>
            <li>Software Developer</li>
            <li>Audio Engineer</li>
            <li>Biomedical Engineer</li>
            <li>Civil Engineer</li>
            <li>Electrical Engineer</li>
            <li>Petroleum Engineer</li>
            <li>Chemist</li>
            <li>Cartographer</li>
            <li>Agricultural Technician</li>
            <li>Physicist</li>
            <li>Science Teacher</li>
            <li>Anesthetist</li>
            <li>Clinical Research Associate</li>
            <li>Oceanographer</li>
            <li>Orthodontist</li>
            <li>Science Teacher</li>
          </ul>
        <h3 class="subtitle">4. GAS (General Academic Strand)</h3>
        <p>Do you still have questions about your interests? Think about the General Academic Strand, or GAS. Unlike other K–12 career-focused courses and strands, GAS gives you the opportunity to think about your options. GAS, a Senior High School strand, uses a generalist approach to prepare students for college. It includes a wide range of academic disciplines, including the social sciences, humanities, management, and organization. Since GAS does not specialize in any one of the three other strands, you are free to choose any college degree programme from them depending on your optional decision. From this thread, education is also a feasible area of study.</p>
        <ul>
          <h3 class="subtitle">Courses</h3>
          <li>Bachelor of Science in Multimedia Art and Sciences (BSMAS)</li>
          <li>Bachelor of Science in Education (BSEd)</li>
          <li>Bachelor of Science in Interior Design (BSID)</li>
          <li>Bachelor of Science in Information Technology (BSIT)</li>
          <li>Bachelor of Science in Digital Cinema (BSDC)</li>
          <li>Bachelor of Science in Psychology (BSP)</li>
          <li>Bachelor of Science in Business Administration (BSBA)</li>
          <li>Bachelor of Science in Biology (BSBio)</li>
          <li>Bachelor of Science in Computer Science (BSCS)</li>
          <li>Bachelor of Science in Environmental Science (BSES)</li>
          <li>Bachelor of Science in Mathematics (BSMath)</li>
          <li>Bachelor of Science in Nursing (BSN)</li>
          <li>Bachelor of Science in Criminology (BSCrim)</li>
          <li>Bachelor of Science in Entrepreneurship (BSE)</li>
          <li>Bachelor of Science in Hospitality Management (BSHM)</li>
          <li>Bachelor of Science in Agriculture (BSAgri)</li>
          <li>Bachelor of Science in Architecture (BSArchi)</li>
          <li>Bachelor of Science in Industrial Engineering (BSIE)</li>
          <li>Bachelor of Science in Public Health (BSPH)</li>
          <li>Bachelor of Science in Food Technology (BSFT)</li>
          <li>Bachelor of Science in Speech-Language Pathology (BSSLP)</li>
          <li>Bachelor of Science in Fisheries (BSFish)</li>
          <li>Bachelor of Science in Forestry (BSF)</li>
          <li>Bachelor of Science in Occupational Therapy (BSOT)</li>
          <li>Bachelor of Public Administration (BPA)</li>
          <li>Bachelor of Tourism Management (BTM)</li>
          <li>Bachelor of Library and Information Science (BLIS)</li>
          <li>Bachelor of Social Work (BSW)</li>
          <li>Bachelor of International Studies or Diplomacy (BISD)</li>
          <li>Bachelor of Laws or Pre-law programs (LL. B or Pre-Law)</li>
          </ul>
          <ul>
          <h3 class="subtitle">Job Opportunities</h3>
          <li>Graphic Designer</li>
          <li>Multimedia Artist</li>
          <li>Animator</li>
          <li>Web Designer</li>
          <li>Teacher</li>
          <li>Curriculum Developer</li>
          <li>Education Administrator</li>
          <li>Interior Designer</li>
          <li>Space Planner</li>
          <li>Furniture Designer</li>
          <li>Software Developer</li>
          <li>Systems Analyst</li>
          <li>Network Administrator</li>
          <li>Film Director</li>
          <li>Cinematographer</li>
          <li>Film Editor</li>
          <li>Psychologist</li>
          <li>Counselor</li>
          <li>Human Resources Specialist</li>
          <li>Business Analyst</li>
          <li>Marketing Manager</li>
          <li>Financial Analyst</li>
          <li>Laboratory Technician</li>
          <li>Environmental Scientist</li>
          <li>Pharmaceutical Sales Representative</li>
          <li>Software Engineer</li>
          <li>IT Project Manager</li>
          <li>Network Administrator</li>
          <li>Environmental Consultant</li>
          <li>Environmental Officer</li>
          <li>Sustainability Specialist</li>
          <li>Actuary</li>
          <li>Data Analyst</li>
          <li>Operations Research Analyst</li>
          <li>Registered Nurse</li>
          <li>Nurse Supervisor</li>
          <li>Nurse Educator</li>
          <li>Criminologist</li>
          <li>Law Enforcement Officer</li>
          <li>Corrections Officer</li>
          <li>Entrepreneur/Small Business Owner</li>
          <li>Hotel Manager</li>
          <li>Restaurant Manager</li>
          <li>Event Coordinator</li>
          <li>Agricultural Scientist</li>
          <li>Farm Manager</li>
          <li>Agricultural Extension Officer</li>
          </ul>
        <h3 class="subtitle">5. EIM (Electrical Installation and Maintenance)</h3>
        <p>The EIM (Electrical Installation and Maintenance) strand is all about mastering the ins and outs of electrical systems. From wiring buildings to fixing electrical glitches, you'll learn the skills needed to install, repair, and maintain electrical setups like a pro. It's perfect for those who love working with wires and circuits and want to spark up their career in the electrical field.</p>
        <ul>
          <h3 class="subtitle">Courses</h3>
            <li>Electrical Engineering</li>
            <li>Electrical Technology</li>
            <li>Electronics Engineering</li>
            <li>Industrial Technology major in Electrical Technology</li>
            <li>Electrical Systems Technology</li>
            <li>Power Systems Engineering</li>
            <li>Electrical and Electronics Engineering Technology</li>
            <li>Renewable Energy Engineering</li>
            <li>Building and Wiring Installation Technology</li>
            <li>Instrumentation and Control Engineering</li>
          </ul>
          <ul>
          <h3 class="subtitle">Job Opportunities</h3>
          <li>Electrician</li>
          <li>Electrical Technician</li>
          <li>Electrical Engineer</li>
          <li>Electrical Supervisor</li>
          <li>Maintenance Technician</li>
          <li>Instrumentation Technician</li>
          <li>Building Maintenance Engineer</li>
          <li>Electrical Drafter</li>
          <li>Power Plant Technician</li>
          <li>Renewable Energy Technician</li>
          </ul>
        <h3 class="subtitle">6. HUMSS (The Humanities and Social Sciences Strand)</h3>
        <p> Covers topics in the liberal arts, training students to think, write, and speak about various humanistic and societal concerns. Students taking up this strand undergo classes designed to hone the mind, improve social skills, introduce cultural and linguistic diversity, and multi-disciplinary critical thinking. T.I.P. HUMSS paves the way for those looking to take up higher education in the arts, political science, literature, anthropology, philosophy, linguistics, communication, psychology, and other related fields.</p>
        <ul>
        <h3 class="subtitle">Job Opportunities</h3>
          <li>Teacher</li>
          <li>Lawyer</li>
          <li>Psychologist</li>
          <li>Author/Editor</li>
          <li>Politician</li>
          <li>Criminologist</li>
          <li>Journalist</li>
          <li>Police</li>
          <li>News Anchor</li>
          <li>Archaeologist</li>
          <li>College Professor</li>
          <li>Consultant</li>
          <li>Cultural Anthropologist</li>
          <li>Editor/Writer</li>
          <li>Geologist</li>
          <li>Historian</li>
        </ul>
        <h3 class="subtitle">7. ICT (Information and Communication Technology)</h3>
        <p>Do you love anything tech-related? Does the digital world capture your interest and curiosity? Information and Communications Technology (ICT) track is the right one for you. ICT is a Senior High School strand that prepares you for a career in Information and Communication Technology. It equips you with advanced skills in computer systems, programming, creating web pages, and basic animation.</p>
        <ul>
          <h3 class="subtitle">Courses</h3>
            <li>Bachelor of Science in Information Technology (BSIT)</li>
            <li>Bachelor of Science in Computer Science (BSCS)</li>
            <li>Bachelor of Science in Information Systems (BSIS)</li>
            <li>Bachelor of Science in Computer Engineering (BSCpE)</li>
            <li>Bachelor of Science in Software Engineering (BSSE)</li>
          </ul>
          <ul>
          <h3 class="subtitle">Job Opportunities</h3>
            <li>Software Developer/Engineer</li>
            <li>IT Support Specialist</li>
            <li>Network Administrator</li>
            <li>Systems Analyst</li>
            <li>Web Developer</li>
            <li>Database Administrator</li>
            <li>Cybersecurity Specialist</li>
            <li>Mobile App Developer</li>
            <li>IT Project Manager</li>
            <li>Data Scientist</li>
          </ul>
        <h3 class="subtitle">8. HE (Home Economics Strand)</h3>
        <p>Teaches different skills you can use at home to start small businesses. It helps you learn practical skills for finding jobs or starting your own projects.</p>
        <ul>
          <h3 class="subtitle">Courses</h3>
            <li>Bachelor of Science in Hotel and Restaurant Management (BSHRM)</li>
            <li>Bachelor of Science in Nutrition and Dietetics (BSND)</li>
            <li>Bachelor of Science in Food Technology (BSFT)</li>
            <li>Bachelor of Science in Clothing Technology (BSCT)</li>
            <li>Bachelor of Science in Family and Consumer Sciences (BSFCS)</li>
            <li>Bachelor of Science in Hospitality Management (BSHM)</li>
          </ul>
          <ul>
          <h3 class="subtitle">Job Opportunities</h3>
            <li>Nutritionist/Dietitian</li>
            <li>Food Technologist</li>
            <li>Textile and Clothing Technologist</li>
            <li>Hotel and Restaurant Manager</li>
            <li>Family and Consumer Sciences Teacher</li>
            <li>Community Development Worker</li>
            <li>Chef</li>
            <li>Pastry Chef/Baker</li>
            <li>Housekeeping Manager</li>
            <li>Event Planner/Coordinator</li>
          </ul>
        <h3 class="subtitle">9. Machining Strand</h3>
        <p>Provides students with comprehensive training in machining and metalworking techniques, including milling, turning, and CNC machining. The program covers topics such as blueprint reading, precision measurement, and machine maintenance. Graduates are prepared for careers in manufacturing, automotive, aerospace, and engineering industries as machinists, CNC operators, and production technicians.</p>
        <ul>
        <h3 class="subtitle">Job Opportunities</h3>
          <li>Machinist</li>
          <li>CNC Operator</li>
          <li>Tool and Die Maker</li>
          <li>Production Technician</li>
          </ul>
        <h3 class="subtitle">10. TG (Tour Guiding)</h3>
        <p>Focuses on training individuals to become proficient guides who provide informative, engaging, and safe tours for tourists. This strand typically covers topics such as local history, culture, geography, hospitality, and communication skills. Students learn how to lead tours, manage groups, and provide exceptional customer service. Training may include practical experience in tourist destinations to develop hands-on skills.</p>
        <h3 class="subtitle">Job Opportunities</h3>
          <li>Tour Guide</li>
          <li>Travel Agent</li>
          <li>Tour Coordinator</li>
          <li>Cultural Educator</li>
          <li>Destination Specialist</li>
          <li>Event Coordinator</li>
          </ul>
      </div>
    </div>
  </section>

  <!-- Footer -->
  <footer class="footer" style="padding-top: 1rem; padding-bottom: 1rem;">
    <div class="content has-text-centered">
        <p class="has-text-centered">&copy; 2024 Career Path Explorer. All rights reserved.</p>
    </div>
</footer>


  <script>
    document.addEventListener('DOMContentLoaded', () => {
      const $navbarBurgers = Array.prototype.slice.call(document.querySelectorAll('.navbar-burger'), 0);

      if ($navbarBurgers.length > 0) {
        $navbarBurgers.forEach(el => {
          el.addEventListener('click', () => {
            const target = el.dataset.target;
            const $target = document.getElementById(target);

            el.classList.toggle('is-active');
            $target.classList.toggle('is-active');
          });
        });
      }
    });
  </script>
</body>

</html>
