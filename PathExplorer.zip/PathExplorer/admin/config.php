<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "user_cb";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Default admin credentials
$default_admin_name = "admin";
$default_admin_email = "admin@gmail.com";
$default_admin_password = md5("admin"); // You can use a more secure hash and password

// Check if the admin user already exists
$check_admin_query = "SELECT * FROM admin_users WHERE email = '$default_admin_email'";
$result = mysqli_query($conn, $check_admin_query);

if (mysqli_num_rows($result) == 0) {
    // Insert default admin user if not exists
    $insert_admin_query = "INSERT INTO admin_users (name, email, password) VALUES ('$default_admin_name', '$default_admin_email', '$default_admin_password')";
    if (mysqli_query($conn, $insert_admin_query)) {
        echo "Default admin user created successfully.";
    } else {
        echo "Error: " . $insert_admin_query . "<br>" . mysqli_error($conn);
    }
}
?>
