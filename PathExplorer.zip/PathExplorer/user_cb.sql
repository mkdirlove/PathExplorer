-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 14, 2024 at 12:25 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `user_cb`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_users`
--

CREATE TABLE `admin_users` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin_users`
--

INSERT INTO `admin_users` (`id`, `name`, `email`, `password`) VALUES
(2, 'admin', 'admin@gmail.com', '21232f297a57a5a743894a0e4a801fc3');

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

CREATE TABLE `questions` (
  `id` int(11) NOT NULL,
  `category` varchar(255) NOT NULL,
  `question_text` text NOT NULL,
  `question_type` enum('text','radio') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `questions`
--

INSERT INTO `questions` (`id`, `category`, `question_text`, `question_type`) VALUES
(1, 'Personal Interests and Hobbies', 'Do you like working with your hands, such as building or crafting things?', 'radio'),
(2, 'Personal Interests and Hobbies', 'Do you enjoy drawing, painting, or other forms of art?', 'radio'),
(3, 'Personal Interests and Hobbies', 'Do you like solving puzzles or playing strategy games?', 'radio'),
(4, 'Personal Interests and Hobbies', 'Are you interested in writing stories or poems?', 'radio'),
(5, 'Personal Interests and Hobbies', 'Do you enjoy reading books?', 'radio'),
(6, 'Personal Interests and Hobbies', 'Do you like playing sports or engaging in physical activities?', 'radio'),
(7, 'Personal Interests and Hobbies', 'Are you interested in cooking or baking?', 'radio'),
(8, 'Personal Interests and Hobbies', 'Do you enjoy gardening or caring for plants?', 'radio'),
(9, 'Personal Interests and Hobbies', 'Are you passionate about acting or performing in front of others?', 'radio'),
(10, 'Personal Interests and Hobbies', 'Do you like taking photographs or making videos?', 'radio'),
(11, 'Personal Interests and Hobbies', 'Do you enjoy participating in science experiments or activities?', 'radio'),
(12, 'Personal Interests and Hobbies', 'Are you interested in programming or working with computers?', 'radio'),
(13, 'Personal Interests and Hobbies', 'Do you like organizing events or planning activities?', 'radio'),
(14, 'Personal Interests and Hobbies', 'Are you interested in fashion and design?', 'radio'),
(15, 'Personal Interests and Hobbies', 'Do you enjoy traveling and learning about different cultures?', 'radio'),
(16, 'Academic Preferences and Strengths', 'What is your favorite subject in school?', 'text'),
(17, 'Academic Preferences and Strengths', 'Do you prefer subjects that involve a lot of reading and writing, like English or history?', 'radio'),
(18, 'Academic Preferences and Strengths', 'Do you enjoy subjects that involve problem-solving and logic, like math or science?', 'radio'),
(19, 'Academic Preferences and Strengths', 'Are you interested in subjects that involve creativity, like art or music?', 'radio'),
(20, 'Academic Preferences and Strengths', 'Do you prefer hands-on subjects, like technology or home economics?', 'radio'),
(21, 'Academic Preferences and Strengths', 'Are you interested in learning about how things work, like in physics or engineering?', 'radio'),
(22, 'Academic Preferences and Strengths', 'Do you enjoy studying living organisms and the environment, like in biology?', 'radio'),
(23, 'Academic Preferences and Strengths', 'Are you interested in studying the human mind and behavior, like in psychology?', 'radio'),
(24, 'Academic Preferences and Strengths', 'Do you enjoy learning about past events and different cultures, like in history or social studies?', 'radio'),
(25, 'Academic Preferences and Strengths', 'Are you interested in learning how businesses operate and manage finances, like in accounting or economics?', 'radio'),
(26, 'Academic Preferences and Strengths', 'Do you enjoy debating and discussing various topics?', 'radio'),
(27, 'Academic Preferences and Strengths', 'Are you interested in legal studies and understanding laws?', 'radio'),
(28, 'Academic Preferences and Strengths', 'Are you good at explaining concepts and teaching others?', 'radio'),
(29, 'Academic Preferences and Strengths', 'Do you enjoy working on group projects and collaborating with others?', 'radio'),
(30, 'Academic Preferences and Strengths', 'Do you enjoy using technology and learning about new software or tools?', 'radio'),
(31, 'Academic Preferences and Strengths', 'Are you interested in health and wellness, like in physical education or health sciences?', 'radio'),
(32, 'Career Interests and Aspirations', 'Are you interested in becoming a doctor, nurse, or healthcare professional?', 'radio'),
(33, 'Career Interests and Aspirations', 'Do you see yourself working in a business or corporate environment?', 'radio'),
(34, 'Career Interests and Aspirations', 'Are you interested in becoming an engineer or working in the field of technology?', 'radio'),
(35, 'Career Interests and Aspirations', 'Do you aspire to be a teacher or educator?', 'radio'),
(36, 'Career Interests and Aspirations', 'Are you interested in pursuing a career in the arts, such as a musician, artist, or actor?', 'radio'),
(37, 'Career Interests and Aspirations', 'Do you want to work in law enforcement or become a lawyer?', 'radio'),
(38, 'Career Interests and Aspirations', 'Are you interested in working in environmental conservation or wildlife protection?', 'radio'),
(39, 'Career Interests and Aspirations', 'Do you see yourself as an entrepreneur or business owner?', 'radio'),
(40, 'Career Interests and Aspirations', 'Are you interested in becoming a scientist or researcher?', 'radio'),
(41, 'Career Interests and Aspirations', 'Do you want to work in the hospitality or tourism industry?', 'radio'),
(42, 'Career Interests and Aspirations', 'Are you interested in a career in sports or fitness?', 'radio'),
(43, 'Career Interests and Aspirations', 'Do you see yourself working in media or communications, such as a journalist or public relations specialist?', 'radio'),
(44, 'Career Interests and Aspirations', 'Are you interested in pursuing a career in fashion or design?', 'radio'),
(45, 'Career Interests and Aspirations', 'Do you want to work in the culinary arts, such as a chef or pastry chef?', 'radio'),
(46, 'Career Interests and Aspirations', 'Are you interested in a career in social work or counseling?', 'radio'),
(47, 'Career Interests and Aspirations', 'Do you see yourself working in government or public service?', 'radio'),
(48, 'Career Interests and Aspirations', 'Are you interested in becoming a writer or author?', 'radio'),
(49, 'Career Interests and Aspirations', 'Do you want to work in the field of technology, such as a software developer or IT specialist?', 'radio'),
(50, 'Career Interests and Aspirations', 'Are you interested in pursuing a career in education administration or policy-making?', 'radio');

-- --------------------------------------------------------

--
-- Table structure for table `responses`
--

CREATE TABLE `responses` (
  `id` int(11) NOT NULL,
  `user_name` varchar(255) NOT NULL,
  `question_id` int(11) DEFAULT NULL,
  `answer` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `responses`
--

INSERT INTO `responses` (`id`, `user_name`, `question_id`, `answer`) VALUES
(202, 'mkdirlove', 1, 'Yes'),
(203, 'mkdirlove', 2, 'Yes'),
(204, 'mkdirlove', 3, 'Yes'),
(205, 'mkdirlove', 4, 'No'),
(206, 'mkdirlove', 5, 'No'),
(207, 'mkdirlove', 6, 'No'),
(208, 'mkdirlove', 7, 'No'),
(209, 'mkdirlove', 8, 'No'),
(210, 'mkdirlove', 9, 'Yes'),
(211, 'mkdirlove', 10, 'Yes'),
(212, 'mkdirlove', 11, 'No'),
(213, 'mkdirlove', 12, 'No'),
(214, 'mkdirlove', 13, 'No'),
(215, 'mkdirlove', 14, 'Yes'),
(216, 'mkdirlove', 15, 'No'),
(217, 'mkdirlove', 16, 'none'),
(218, 'mkdirlove', 17, 'No'),
(219, 'mkdirlove', 18, 'No'),
(220, 'mkdirlove', 19, 'Yes'),
(221, 'mkdirlove', 20, 'No'),
(222, 'mkdirlove', 21, 'No'),
(223, 'mkdirlove', 22, 'No'),
(224, 'mkdirlove', 23, 'No'),
(225, 'mkdirlove', 24, 'No'),
(226, 'mkdirlove', 25, 'No'),
(227, 'mkdirlove', 26, 'No'),
(228, 'mkdirlove', 27, 'No'),
(229, 'mkdirlove', 29, 'No'),
(230, 'mkdirlove', 30, 'No'),
(231, 'mkdirlove', 31, 'No'),
(232, 'mkdirlove', 32, 'No'),
(233, 'mkdirlove', 33, 'No'),
(234, 'mkdirlove', 34, 'No'),
(235, 'mkdirlove', 35, 'No'),
(236, 'mkdirlove', 36, 'Yes'),
(237, 'mkdirlove', 37, 'No'),
(238, 'mkdirlove', 38, 'No'),
(239, 'mkdirlove', 39, 'No'),
(240, 'mkdirlove', 40, 'No'),
(241, 'mkdirlove', 41, 'No'),
(242, 'mkdirlove', 42, 'No'),
(243, 'mkdirlove', 43, 'No'),
(244, 'mkdirlove', 44, 'Yes'),
(245, 'mkdirlove', 45, 'No'),
(246, 'mkdirlove', 46, 'No'),
(247, 'mkdirlove', 47, 'No'),
(248, 'mkdirlove', 48, 'No'),
(249, 'mkdirlove', 49, 'No'),
(250, 'mkdirlove', 50, 'No');

-- --------------------------------------------------------

--
-- Table structure for table `user_form`
--

CREATE TABLE `user_form` (
  `id` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `user_type` varchar(255) NOT NULL DEFAULT 'user'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_form`
--

INSERT INTO `user_form` (`id`, `name`, `email`, `password`, `user_type`) VALUES
(0, 'Carl Andrae F. Macaubos', 'carlandraemacaubos@gmail.com', '3924bdbac65e9c4951f0db51b9ed8a7a', 'admin'),
(0, 'Eva Macaubos', 'evamacaubos@gmail.com', '08c9371ae005cdefed132f2606c7e7f3', 'user'),
(0, 'Byron Roberto', 'byronroberto14524@gmail.com', 'cd4108a569f53f390c652aac346517bf', 'admin'),
(0, 'mkdirlove', 'mkdirlove@dph.gov', '266b327d8120c75c67bd347eabf7ab49', 'admin'),
(0, 'sudo', 'sudo@dph.gov', 'd338b3f0f405eb5e51c8cc1e5ca66f02', 'user'),
(0, 'test', 'test@gmail.com', '098f6bcd4621d373cade4e832627b4f6', 'user');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_users`
--
ALTER TABLE `admin_users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `questions`
--
ALTER TABLE `questions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `responses`
--
ALTER TABLE `responses`
  ADD PRIMARY KEY (`id`),
  ADD KEY `question_id` (`question_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_users`
--
ALTER TABLE `admin_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `questions`
--
ALTER TABLE `questions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;

--
-- AUTO_INCREMENT for table `responses`
--
ALTER TABLE `responses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=301;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `responses`
--
ALTER TABLE `responses`
  ADD CONSTRAINT `responses_ibfk_1` FOREIGN KEY (`question_id`) REFERENCES `questions` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
