<?php
session_start();
include_once 'config.php';

if (!isset($_SESSION['user_name'])) {
    header('location: signin.php');
    exit;
}

if (isset($_GET['take_quiz_again'])) {
    $user_name = $_SESSION['user_name'];
    $delete_query = "DELETE FROM responses WHERE user_name = '$user_name'";
    if (mysqli_query($conn, $delete_query)) {
        header('Location: quiz.php');
        exit;
    } else {
        echo "Error deleting responses: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quiz Confirmation</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bulma/0.9.3/css/bulma.min.css">
</head>
<body>
    <nav class="navbar is-info has-navbar-fixed-top" role="navigation" aria-label="main navigation">
    </nav>

    <section class="section">
        <div class="container">
            <div class="notification is-primary has-text-centered">
                <h1 class="title">Thank you for completing the quiz!</h1>
                <p>Your responses have been recorded.</p>
                <div class="buttons is-centered" style="margin-top: 20px;">
                    <a class="button is-link" href="dashboard.php">Return to Dashboard</a>
                    <a class="button is-primary" href="quiz_confirmation.php?take_quiz_again=true">Take the Quiz Again</a>
                </div>
            </div>
        </div>
    </section>
</body>
</html>
