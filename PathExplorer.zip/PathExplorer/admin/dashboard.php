<?php
session_start();

if (!isset($_SESSION['admin_name'])) {
    header('location:login.php');
    exit;
}

@include 'config.php';

if (isset($_POST['add_user'])) {
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = md5(mysqli_real_escape_string($conn, $_POST['password']));

    $insert = "INSERT INTO user_form(name, email, password) VALUES('$name', '$email', '$password')";
    mysqli_query($conn, $insert);
    header('location:dashboard.php');
}

if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $delete = "DELETE FROM users WHERE id = $id";
    mysqli_query($conn, $delete);
    header('location:dashboard.php');
}

if (isset($_POST['update_user'])) {
    $id = $_POST['id'];
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = md5(mysqli_real_escape_string($conn, $_POST['password']));

    $update = "UPDATE user_form SET name = '$name', email = '$email', password = '$password' WHERE id = $id";
    mysqli_query($conn, $update);
    header('location:dashboard.php');
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600&display=swap');

        * {
            font-family: 'Poppins', sans-serif;
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            outline: none;
            border: none;
            text-decoration: none;
        }

        body {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background: #f0f0f0;
        }

        .container {
            background: #fff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            text-align: center;
            width: 80%;
            max-width: 1000px;
        }

        .container h1 {
            font-size: 2rem;
            margin-bottom: 20px;
        }

        .container form input,
        .container form button {
            margin: 10px 0;
            padding: 10px;
            width: 100%;
            font-size: 1rem;
        }

        .container form button {
            background: crimson;
            color: #fff;
            border-radius: 5px;
            cursor: pointer;
        }

        .container table {
            width: 100%;
            margin-top: 20px;
            border-collapse: collapse;
        }

        .container table th,
        .container table td {
            padding: 10px;
            border: 1px solid #ccc;
            text-align: left;
        }

        .container .btn {
            display: inline-block;
            padding: 5px 10px;
            background: crimson;
            color: #fff;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
            transition: background 0.3s;
        }

        .container .btn:hover {
            background: #333;
        }

        .container .edit-form {
            display: none;
        }
    </style>
</head>
<body>

<div class="container">
    <h1>Welcome, <?php echo htmlspecialchars($_SESSION['admin_name']); ?>!</h1>
    <h2>Admin Dashboard</h2>
    <a href="logout.php" class="btn">Logout</a>

    <h3>Add New User</h3>
    <form action="" method="post">
        <input type="text" name="name" placeholder="Enter name" required>
        <input type="email" name="email" placeholder="Enter email" required>
        <input type="password" name="password" placeholder="Enter password" required>
        <button type="submit" name="add_user">Add User</button>
    </form>

    <h3>Manage Users</h3>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $select = "SELECT * FROM user_form";
            $result = mysqli_query($conn, $select);
            while ($row = mysqli_fetch_assoc($result)) {
                echo "<tr>
                    <td>{$row['id']}</td>
                    <td>{$row['name']}</td>
                    <td>{$row['email']}</td>
                    <td>
                        <a href='?delete={$row['id']}' class='btn'>Delete</a>
                        <a href='#' class='btn edit-btn' data-id='{$row['id']}' data-name='{$row['name']}' data-email='{$row['email']}'>Edit</a>
                    </td>
                </tr>";
            }
            ?>
        </tbody>
    </table>

    <div class="edit-form">
        <h3>Edit User</h3>
        <form action="" method="post">
            <input type="hidden" name="id" id="edit-id">
            <input type="text" name="name" id="edit-name" placeholder="Enter name" required>
            <input type="email" name="email" id="edit-email" placeholder="Enter email" required>
            <input type="password" name="password" placeholder="Enter new password" required>
            <button type="submit" name="update_user">Update User</button>
        </form>
    </div>

</div>

<script>
    document.querySelectorAll('.edit-btn').forEach(button => {
        button.addEventListener('click', event => {
            event.preventDefault();
            document.querySelector('.edit-form').style.display = 'block';
            document.getElementById('edit-id').value = button.getAttribute('data-id');
            document.getElementById('edit-name').value = button.getAttribute('data-name');
            document.getElementById('edit-email').value = button.getAttribute('data-email');
        });
    });
</script>

</body>
</html>
